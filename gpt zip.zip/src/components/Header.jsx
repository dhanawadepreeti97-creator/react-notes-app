import { FaStickyNote } from "react-icons/fa";

function Header() {
  return (
    <header className="header">

      <div className="title">

        <FaStickyNote className="logo"/>

        <div>

          <h1>Notes Dashboard</h1>

          <p>Organize your thoughts beautifully</p>

        </div>

      </div>

    </header>
  );
}

export default Header;